
public class Memento 
{
	private double state;

	   public Memento(double state2){
	      this.state = state2;
	   }

	   public double getState(){
	      return state;
	   }	
}
