import java.util.Scanner;
import java.util.Stack;

public class Main {

	static Scanner sc=new Scanner(System.in);
	
	Originator originator = new Originator();
    CareTaker careTaker = new CareTaker();
	public void add(Double a, Double b)
	{
		double sum=0;
		sum=a+b;
		System.out.println("Sum= "+sum);
		originator.setState(sum);
	    careTaker.add(originator.saveStateToMemento());
	}
	public void sub(Double a1, Double b1)
	{
		double sub=0;
		sub=a1-b1;
		System.out.println("Sub= "+sub);
		originator.setState(sub);
	    careTaker.add(originator.saveStateToMemento());
	}
	public void multi(Double a2, Double b2)
	{
		double mul=0;
		mul=a2*b2;
		System.out.println("Mul= "+mul);
		originator.setState(mul);
	    careTaker.add(originator.saveStateToMemento());
	}
	public void div(Double a3, Double b3)
	{
		double div=0;	
		if(b3==0)
		{
			System.out.println("Second number cannot be 0!! Enter again");
			b3=sc.nextDouble();
		}
		div=a3/b3;
		System.out.println("Div= "+div);
		originator.setState(div);
	    careTaker.add(originator.saveStateToMemento());
	}
	public double show(int v)
	{
		originator.getStateFromMemento(careTaker.get(v));
	    System.out.println("Saved State at "+v+" is: "+originator.getState());
	    return originator.getState();
	}
	public void approx(double num1,int f)
	{
		Stack <Integer> stack = new Stack<Integer>();
		int aarr[]=new int[512];
		int i=0;
		String num=String.valueOf(num1);
		String [] arr=num.split("\\.");
        String part2=arr[1];
        long part22=Long.parseLong(part2.trim());
        while (part22 > 0) 
        {
        	String temp=String.valueOf(part22 % 10);
        	int te=Integer.parseInt(temp);
        	stack.push(te );
            part22= part22 / 10;
        }
        while (!stack.isEmpty()) 
        {
            aarr[i]=stack.pop();
            i=i+1;
        }
        int result=factorial(f);
        String fin=arr[0].concat(".");
        for(int k=0;k<result;k++)
        {
        	fin=fin.concat(String.valueOf(aarr[k]));
        }
        System.out.println(fin);
        originator.setState(Double.parseDouble(fin));
	    careTaker.add(originator.saveStateToMemento());
	}
	
	static int factorial(int n)
	{    
		  if (n == 0)    
		    return 1;    
		  else    
		    return(n * factorial(n-1));    
	}
	public void find(double num,int f)
	{
		Stack <Integer> stack = new Stack<Integer>();
		int aarr[]=new int[512];
		int i=0;
		String numm=String.valueOf(num);
		String [] arr=numm.split("\\.");
        String part2=arr[1];
        System.out.println(arr[1]);
        long part22=Long.parseLong(part2.trim());
        while (part22 > 0) 
        {
        	String temp=String.valueOf(part22 % 10);
        	int te=Integer.parseInt(temp);
        	stack.push(te );
            part22= part22 / 10;
        }
        while (!stack.isEmpty()) 
        {
            aarr[i]=stack.pop();
            i=i+1;
        }
        int result=factorial(f);
        System.out.println("Value at "+f+" is "+aarr[result-1]);
        originator.setState(Double.parseDouble(String.valueOf(aarr[result-1])));
	    careTaker.add(originator.saveStateToMemento());
		
	}
	public static void main(String[] args) 
	{
		Main ob=new Main();
		while(true)
		{
			System.out.println("Press '+' for Addition\n"
					+ "Press '-' For Subtraction\n"+
					"Press '*' for Multiplication\n"+
					"Press '/'for Division\n"+
					"Press '#' to access memory location\n"+
					"Press 'c' for special operation");
			String c=sc.next();
			System.out.println(c);
			switch(c)
			{
			case"+":
				Double a,b;
				System.out.println("Enter First Number");
				a=sc.nextDouble();
				System.out.println("Enter Second Number");
				b=sc.nextDouble();
				ob.add(a,b);
			break;
			
			case"-":
				Double a0,b0;
				System.out.println("Enter First Number");
				a0=sc.nextDouble();
				System.out.println("Enter Second Number");
				b0=sc.nextDouble();
				ob.sub(a0,b0);
			break;
			case"*":
				Double a2,b2;
				System.out.println("Enter First Number");
				a2=sc.nextDouble();
				System.out.println("Enter Second Number");
				b2=sc.nextDouble();
				ob.multi(a2,b2);
			break;
			case"/":
				Double a3,b3;
				System.out.println("Enter First Number");
				a3=sc.nextDouble();
				System.out.println("Enter Second Number");
				b3=sc.nextDouble();
				ob.div(a3,b3);
			break;
			case"#":
			System.out.println("Enter a saved state number");
			int v=sc.nextInt();
			ob.show(v);
			break;
			case"c":System.out.println("Press 1 to find out the value at particular factorial\n"+
			"Press 2 to approximate value till particular factorial");
			int x=sc.nextInt();
			if(x==1)
			{
				System.out.println("Press 1 to fetch result from the memory\n"+
						"Press 2 to enter number by yourself");
						int temp=sc.nextInt();
				if(temp==1)
				{
					System.out.println("Enter State number");
					int v1=sc.nextInt();
					double a1=ob.show(v1);
					System.out.println("Enter the factorial position number");
					int f=sc.nextInt();
					ob.find(a1, f);
				}
				else if(temp==2)
				{
				System.out.println("Enter the factorial number whose value you need to find out");
				double nummm=sc.nextDouble();
				System.out.println("Enter the factorial position number");
				int f=sc.nextInt();
				ob.find(nummm,f);
				}
				else
				{
					System.out.println("Invalid choice");
				}
				
			}
			else if(x==2)
			{
			System.out.println("Press 1 to fetch result from the memory\n"+
			"Press 2 to enter number by yourself");
			int temp=sc.nextInt();
			if(temp==1)
			{	System.out.println("Enter State number");
				int v1=sc.nextInt();
				double a1=ob.show(v1);
				System.out.println("Enter the factorial number to which value need to be approximated");
				int f=sc.nextInt();
				ob.approx(a1,f);
			}
			else if(temp==2)
			{
				System.out.println("Enter Number");
				double v2=sc.nextDouble();
				System.out.println("Enter the factorial number to which value need to be approximated");
				int f=sc.nextInt();
				ob.approx(v2,f);
			}
			}
			else
			System.out.println("Invalid choice");
			break;
			}
			
		}
	}

}
